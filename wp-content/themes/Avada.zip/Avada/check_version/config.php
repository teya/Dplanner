<?php
// your envato username (used for affiliate urls).
$envato_username = 'phpBros';


// website settings.
$website['name']                = 'WhatPress ';
$website['description']         = 'Find what WordPress theme a website is using by checking a URL with our free online WordPress theme tool.';
$website['url']                 = 'http://whatpress.net/';
$website['year']                = date('Y');
$website['sidebar_description'] = 'WhatPress will find theme information for WordPress websites, including theme name, author and URL just paste the URL in the search box and hit enter!';
?>