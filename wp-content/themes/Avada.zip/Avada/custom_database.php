<?php /* Template name: Manage */ ?>
<?php get_header(); ?>